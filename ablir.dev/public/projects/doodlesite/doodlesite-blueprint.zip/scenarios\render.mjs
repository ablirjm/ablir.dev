// Renders every doodle in scenarios/doodles/*.html to scenarios/out/<name>/doodle.png using headless Edge or Chrome.
// Scenarios flagged `clean: true` also get doodle-clean.png: the same photo after the app's clean-up handler
// (src/lib/photo-core.js), produced by running that exact routine in the browser.
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
export const BROWSER = [
  "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
  "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
  "C:/Program Files/Google/Chrome/Application/chrome.exe",
  "/usr/bin/google-chrome",
  "/usr/bin/chromium",
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
].find(existsSync);

export function screenshot(url, out, { width = 1200, height = 800, budget = 3000, dark = false } = {}) {
  if (!BROWSER) throw new Error("No Edge or Chrome found for screenshots.");
  mkdirSync(path.dirname(out), { recursive: true });
  execFileSync(
    BROWSER,
    [
      "--headless=new",
      "--disable-gpu",
      "--hide-scrollbars",
      ...(dark ? ["--force-dark-mode"] : []),
      `--window-size=${width},${height}`,
      `--virtual-time-budget=${budget}`,
      `--screenshot=${out}`,
      url,
    ],
    { stdio: "ignore", timeout: 60_000 },
  );
}

/** Runs the client's photo clean-up on a PNG by rendering it through a canvas page, then screenshots the result. */
export function cleanPng(srcPng, outPng, { width = 1200, height = 800 } = {}) {
  const core = readFileSync(path.join(here, "..", "src", "lib", "photo-core.js"), "utf8");
  const dataUrl = `data:image/png;base64,${readFileSync(srcPng).toString("base64")}`;
  const page = `<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:#fff}canvas{display:block}</style>
<canvas id="c" width="${width}" height="${height}"></canvas>
<script type="module">
${core}
const c = document.getElementById("c"); const ctx = c.getContext("2d", { willReadFrequently: true });
const img = new Image();
img.onload = () => { ctx.drawImage(img, 0, 0, ${width}, ${height}); const d = ctx.getImageData(0, 0, ${width}, ${height}); enhanceSketch(d.data, ${width}, ${height}); ctx.putImageData(d, 0, 0); };
img.src = ${JSON.stringify(dataUrl)};
</script>`;
  const pagePath = path.join(path.dirname(outPng), "_clean-page.html");
  writeFileSync(pagePath, page);
  screenshot(pathToFileURL(pagePath).href, outPng, { width, height, budget: 4000 });
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  const { scenarios } = await import("./scenarios-list.mjs");
  const cleanIds = new Set(scenarios.filter((s) => s.clean && s.doodle).map((s) => s.doodle));
  const dir = path.join(here, "doodles");
  for (const f of readdirSync(dir)) {
    if (!f.endsWith(".html") || f.startsWith("_")) continue;
    const name = f.replace(/\.html$/, "");
    const out = path.join(here, "out", name, "doodle.png");
    screenshot(pathToFileURL(path.join(dir, f)).href, out, { width: 1200, height: 800, budget: 1500 });
    console.log(`rendered ${name} -> ${path.relative(process.cwd(), out)}`);
    if (cleanIds.has(name)) {
      const clean = path.join(here, "out", name, "doodle-clean.png");
      cleanPng(out, clean);
      console.log(`cleaned  ${name} -> ${path.relative(process.cwd(), clean)}`);
    }
  }
}
