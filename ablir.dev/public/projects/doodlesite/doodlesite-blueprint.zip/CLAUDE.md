# DoodleSite

Sketch a layout, add a brief, get a self-contained HTML prototype or an adjusted version of an existing site. React + Vite client in `src/`, Express API in `server/`, Claude reached either through the Anthropic SDK or by spawning the local Claude Code CLI.

## Commands

- `npm run dev` runs client (5173) and API (8787) together; `npm run dev:api` for the API alone.
- `npm run check` runs typecheck plus the parser and prompt tests.
- `npm run scenarios` renders the sketches, runs the end-to-end suite against the local API, and rebuilds `scenarios/out/showcase.html`. Needs the API running and either a logged-in `claude` CLI or an API key. Each scenario takes 2 to 3 minutes.

## Where things live

- The generation prompt is assembled from Markdown modules in `server/skills/` by `buildSystemPrompt` in `server/prompt.ts`. Edit a rule there, not in code.
- Provider adapters: `server/providers/api.ts` (SDK) and `server/providers/claudeCode.ts` (CLI). Both share the output contract (`<<<ANALYSIS>>>`, `<<<HTML>>>`, `<<<END>>>`).
- Scenario suite: `scenarios/` (doodles as SVG, `scenarios-list.mjs` for briefs and checks, `check.mjs` for assertions).
- UI design tokens: top of `src/styles.css`.

## Project skills

Skills in `.claude/skills/` cover the repeatable workflows: `doodle-prompt` (changing generation rules with evidence), `doodle-scenarios` (running and extending the suite), `doodle-design` (keeping the UI on its visual system). The `frontend-design` plugin from the official marketplace is the general design reference this project was built against.

## Conventions

- Keep `server/prompt.ts` free of prose; prose goes in `server/skills/*.md`.
- Any prompt change must be followed by `npm run scenarios:run <affected ids>` and a look at the checks before it is called done.
- The scenario checks are the regression suite for the prompt. Add a check whenever a run exposes a new failure mode.
