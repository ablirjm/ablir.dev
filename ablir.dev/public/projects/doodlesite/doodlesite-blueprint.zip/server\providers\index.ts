import { execFile } from "node:child_process";
import { apiProvider, DEFAULT_API_MODEL } from "./api.js";
import { claudeCodeProvider } from "./claudeCode.js";
import type { Provider, ProviderSettings } from "./types.js";

export type ProviderName = "api" | "claude-code";

export interface ResolvedConfig extends ProviderSettings {
  source: "request" | "env" | "auto";
}

const isWin = process.platform === "win32";

let cliCheck: Promise<{ found: boolean; version?: string }> | null = null;

/** Checks once whether the Claude Code CLI is reachable, cached for the server's lifetime. */
export function checkCli(bin: string): Promise<{ found: boolean; version?: string }> {
  if (!cliCheck) {
    cliCheck = new Promise((resolve) => {
      execFile(bin, ["--version"], { shell: isWin, timeout: 15_000, windowsHide: true }, (err, stdout) => {
        if (err) return resolve({ found: false });
        resolve({ found: true, version: String(stdout).trim().split("\n")[0] });
      });
    });
  }
  return cliCheck;
}

export interface RequestOverrides {
  provider?: string;
  apiKey?: string;
  model?: string;
}

/** Combines per-request overrides (from the app's settings) with .env, falling back to auto-detection. */
export async function resolveSettings(overrides: RequestOverrides): Promise<ResolvedConfig> {
  const cliBin = process.env.CLAUDE_CODE_BIN?.trim() || "claude";
  const apiKey = overrides.apiKey?.trim() || process.env.ANTHROPIC_API_KEY?.trim() || undefined;
  const model = overrides.model?.trim() || process.env.DOODLE_MODEL?.trim() || undefined;

  const requested = (overrides.provider || process.env.DOODLE_PROVIDER || "auto").trim().toLowerCase();
  if (requested === "api") return { provider: "api", apiKey, model, cliBin, source: overrides.provider ? "request" : "env" };
  if (requested === "claude-code" || requested === "cli" || requested === "local")
    return { provider: "claude-code", apiKey, model, cliBin, source: overrides.provider ? "request" : "env" };

  // auto
  if (apiKey) return { provider: "api", apiKey, model, cliBin, source: "auto" };
  return { provider: "claude-code", apiKey, model, cliBin, source: "auto" };
}

export function getProvider(name: ProviderName): Provider {
  return name === "api" ? apiProvider : claudeCodeProvider;
}

export function describeModel(cfg: ResolvedConfig): string {
  if (cfg.model) return cfg.model;
  return cfg.provider === "api" ? DEFAULT_API_MODEL : "Claude Code default";
}
