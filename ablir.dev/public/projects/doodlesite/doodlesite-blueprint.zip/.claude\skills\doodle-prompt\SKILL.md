---
name: doodle-prompt
description: How to change DoodleSite's generation prompt safely. Use when a result shows the model misreading a sketch, ignoring a brief, breaking an adjusted site, or when adding a new capability such as a new mark type or output rule.
---

# Changing the generation prompt

The system prompt is not one string. `buildSystemPrompt` in `server/prompt.ts` joins Markdown modules from `server/skills/` depending on the request:

| Module | Included when | Owns |
|---|---|---|
| `core.md` | always | the role, how to read marks, precedence of brief over sketch |
| `rough.md` | always | tolerance for messy sketches and photos: open boxes, scribbled-out marks, illegible words, repeats, artefacts; what goes in `unclear` |
| `motion.md` | always | the sketch vocabulary for animation (motion lines, swooping arrows, ghost shapes, "fade"/"slide"/"hover"/"scroll"), trigger classification, safe implementation; what goes in `motion` |
| `create.md` | mode is create | rules for a new self-contained page, design quality, no external deps |
| `adjust.md` | mode is adjust | preserving an existing site, updating references when sections move or go |
| `refine.md` | a previous result is attached | applying the new brief as a delta, listing `changes` |
| `output.md` | always | the strict marker format and the analysis JSON shape |

The per-request text (brief, existing markup, previous result, image reference) is built by `buildUserText` in the same file.

## Workflow for a rule change

1. Reproduce. Find or write a scenario in `scenarios/scenarios-list.mjs` that shows the problem, and add a `checks` entry that fails on the bad output. Run `node scenarios/check.mjs <id>` against the existing result to confirm the check catches it.
2. Decide which module owns the rule. A rule about reading marks goes in `core.md`; a rule that only matters when editing an existing page goes in `adjust.md`. Keep each rule one sentence of instruction plus, if needed, one of rationale.
3. Edit the Markdown. Do not touch `prompt.ts` unless the assembly logic itself changes.
4. Run `npm test`. The tests assert which modules each mode includes and that the markers survive.
5. Re-run the affected scenarios with the API up: `npm run dev:api` in one terminal, `node scenarios/run.mjs <id ...>` in another. Archive the previous result first if a before/after comparison matters (`cp -r scenarios/out/<id> scenarios/out/_archive/<id>-<label>`).
6. Rebuild the showcase (`node scenarios/showcase.mjs`) and read the checks. A rule that fixes one scenario and breaks another is not done.

## Rough sketches and photos

Two layers handle ugliness. The client's clean-up handler (`src/lib/photo-core.js`, applied automatically when a photo is added, toggle "Clean photo" in the toolbar) flattens uneven light, pushes paper to white, and keeps saturated ink colours so red notes stay red. Then `rough.md` tells the model how to read what is left. If a messy sketch is misread, first check the cleaned image (the scenario tooling writes `doodle-clean.png`), then the `unclear` list in the analysis, and only then the module.

## Animation instructions

The model is asked to find motion in both the sketch and the brief and to list every instance under `motion` with its trigger. The `ugly-photo` scenario checks the four marks it contains (slide-in arrow, "fade", "hover → lift", "scroll / reveal") produce keyframes, a hover transform, and an IntersectionObserver, and that nothing is parked at opacity 0 without a ready class. When adding a new motion mark to the vocabulary, add it to `motion.md` and to that scenario's sketch.

## Things that look like prompt bugs but are not

- Mojibake in the analysis text when opening `showcase.html` from disk: the page carries a charset meta; the browser is at fault only if that line was removed.
- Missing straight lines in a scenario sketch: the SVG wobble filter must use `filterUnits="userSpaceOnUse"` or zero-height lines vanish.
- Hash links like `#recipe/x` are treated as app routes by the anchor check and ignored on purpose.

## Cost and time

Each scenario is one model call with an image. Through the CLI that is 2 to 3 minutes and uses the user's Claude Code login; through the API it is billed at the configured model's rates. Run only the affected scenarios while iterating; run the full suite before calling a prompt change finished.
