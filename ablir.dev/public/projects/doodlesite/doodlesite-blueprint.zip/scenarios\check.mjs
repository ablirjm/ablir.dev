// Automatic checks on a generated result. Generic checks apply to every scenario; each scenario in
// scenarios-list.mjs can add its own `checks` array of { name, test(html, analysis) -> true | string }.
//
//   node scenarios/check.mjs            re-check every scenario that has a result and update its meta.json
//   node scenarios/check.mjs dashboard  one scenario
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { scenarios } from "./scenarios-list.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const out = (id, f = "") => path.join(here, "out", id, f);

const generic = [
  {
    name: "Complete HTML document",
    test: (h) => (/^\s*<!doctype html/i.test(h) && /<\/html>\s*$/i.test(h)) || "missing doctype or closing </html>",
  },
  { name: "Has a <title>", test: (h) => /<title>[^<]+<\/title>/i.test(h) || "no title" },
  { name: "Viewport meta present", test: (h) => /<meta[^>]+name="viewport"/i.test(h) || "no viewport meta" },
  { name: "No lorem ipsum", test: (h) => !/lorem ipsum/i.test(h) || "placeholder copy found" },
  {
    name: "Every in-page link resolves",
    test: (h) => {
      const ids = new Set([...h.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
      // "#recipe/x"-style hashes are app routes handled by script, not in-page anchors.
      const targets = [...new Set([...h.matchAll(/href="#([^"/]+)"/g)].map((m) => m[1]))];
      const missing = targets.filter((id) => !ids.has(id));
      return missing.length === 0 || `dangling: #${missing.join(", #")}`;
    },
  },
  { name: "No external scripts", test: (h) => !/<script[^>]+src=/i.test(h) || "external <script src> found" },
  { name: "No hotlinked images", test: (h) => !/<img[^>]+src="https?:/i.test(h) || "remote <img src> found" },
  {
    name: "Motion respects reduced-motion",
    test: (h) => !/animation:|transition:/i.test(h) || /prefers-reduced-motion/i.test(h) || "animates without a reduced-motion rule",
  },
  {
    name: "Scroll-reveal content is not hidden without a ready class",
    test: (h) => {
      // Only pages with scroll-triggered reveals can go blank without JavaScript. For those, every rule that
      // hides content must be scoped under a class the script itself adds (".js", ".ready", ...).
      if (!/IntersectionObserver/.test(h)) return true;
      const script = (h.match(/<script[\s\S]*?<\/script>/gi) ?? []).join("\n");
      const added = new Set([...script.matchAll(/classList\.(?:add|toggle)\(\s*["']([^"']+)["']/g)].map((m) => m[1]));
      for (const m of script.matchAll(/className\s*[+]?=\s*["']\s*([\w-]+)/g)) added.add(m[1]);
      const css = (h.match(/<style[\s\S]*?<\/style>/gi) ?? []).join("\n").replace(/\/\*[\s\S]*?\*\//g, "");
      const rules = [...css.matchAll(/([^{}]+)\{([^}]*)\}/g)];
      const unsafe = rules
        .filter(([, sel, body]) => /(^|[;\s])opacity:\s*0(?:[;\s]|$)/.test(body))
        .filter(([, sel, body]) => {
          const s = sel.trim();
          if (/hover|focus|::|:not|\[hidden\]|\[aria-|@keyframes|^\s*(from|to|\d+%)/i.test(s)) return false; // states, pseudo, keyframes
          if (/visibility:\s*hidden|pointer-events:\s*none|display:\s*none|translate[XY]?\(\s*-?(100|[2-9]\d)%/.test(body)) return false; // overlays, sheets
          if ([...added].some((c) => s.includes(`.${c}`))) return false; // scoped under a script-added class
          return !/\.(js|ready|loaded|enhanced|no-js)\b/.test(s);
        })
        .map(([, sel]) => sel.trim());
      return unsafe.length === 0 || `hidden until script runs: ${unsafe.slice(0, 3).join(" | ")}`;
    },
  },
  {
    name: "Analysis reports motion and unclear lists",
    test: (_h, a) => (a && Array.isArray(a.motion) && Array.isArray(a.unclear)) || "motion/unclear arrays missing from the analysis",
  },
];

export function runChecks(html, scenario, analysis = null) {
  const all = [...generic, ...(scenario?.checks ?? [])];
  return all.map((c) => {
    let r;
    try {
      r = c.test(html, analysis);
    } catch (e) {
      r = `check threw: ${e.message}`;
    }
    return { name: c.name, pass: r === true, detail: r === true ? "" : String(r) };
  });
}

export function checkScenario(s) {
  const file = out(s.id, "result.html");
  if (!existsSync(file)) return null;
  const html = readFileSync(file, "utf8");
  const analysisPath = out(s.id, "analysis.json");
  const analysis = existsSync(analysisPath) ? JSON.parse(readFileSync(analysisPath, "utf8")) : null;
  const checks = runChecks(html, s, analysis);
  const metaPath = out(s.id, "meta.json");
  const meta = existsSync(metaPath) ? JSON.parse(readFileSync(metaPath, "utf8")) : { id: s.id };
  meta.checks = checks;
  meta.checksPassed = checks.filter((c) => c.pass).length;
  meta.checksTotal = checks.length;
  writeFileSync(metaPath, JSON.stringify(meta, null, 2));
  return checks;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  const only = process.argv.slice(2);
  for (const s of scenarios) {
    if (only.length && !only.includes(s.id)) continue;
    const checks = checkScenario(s);
    if (!checks) continue;
    const failed = checks.filter((c) => !c.pass);
    console.log(`${failed.length ? "✗" : "✓"} ${s.id}: ${checks.length - failed.length}/${checks.length}`);
    for (const f of failed) console.log(`    ${f.name}: ${f.detail}`);
  }
}
