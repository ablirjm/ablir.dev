# DoodleSite

Sketch a layout, write a one-line brief, and get a working prototype. Or point it at an existing site and sketch what should move.

The doodle gives the model something a text prompt can't: where things sit, how big they are, and what order they read in. The brief fills in what a sketch can't say.

## What it does

- **Sketch** on a gridded sheet with a pen, marker, box, text, and eraser tool, or drop in a photo of a paper sketch and draw on top of it. Red ink is read as a note to the model rather than page content.
- **Brief** the model with supplemental instructions. The brief wins where it conflicts with the sketch; the sketch decides placement where the brief is silent.
- **Build** a self-contained HTML prototype, or **adjust** an existing page (fetched by URL or pasted) to match the sketch.
- **Read** how the model interpreted each mark, and which gaps it filled.
- **Refine** in rounds. Every build lands as a version; the next brief can build on any of them.

## Two ways to reach Claude

| Provider | What it needs | How it works |
|---|---|---|
| Local Claude Code | The `claude` CLI installed and logged in | Spawns `claude -p` with the sketch saved to a temp file and the tools limited to `Read` |
| Anthropic API | An API key | Calls the Messages API with the sketch attached as an image, `claude-opus-5` by default |

With `DOODLE_PROVIDER=auto` (the default) the server uses the API when a key is present and the CLI otherwise. The in-app settings panel can override the provider, key, and model per browser.

## Run it

```bash
npm install
cp .env.example .env      # optional; everything also works from the settings panel
npm run dev
```

Open http://localhost:5173. The API server listens on port 8787 and Vite proxies `/api` to it.

For a production build: `npm run build`, then `npm start` serves the built client and the API from one port.

## Configuration

See `.env.example`. Server-side defaults:

- `DOODLE_PROVIDER` — `auto`, `api`, or `claude-code`
- `ANTHROPIC_API_KEY` — for the API provider
- `DOODLE_MODEL` — model override for either provider
- `CLAUDE_CODE_BIN` — path to the CLI if it is not on `PATH`

## Layout

```
server/            Express API
  index.ts         /api/health, /api/generate (SSE), /api/fetch-site
  prompt.ts        assembles the system prompt, builds requests, parses output
  prompt.test.ts   node:test suite for the above (npm test)
  skills/          prompt modules: core, create, adjust, refine, output
  providers/       api.ts (SDK), claudeCode.ts (CLI), index.ts (resolution)
src/               React client (Vite)
  components/      SketchPanel, BriefPanel, PreviewPane, SettingsDrawer, TopBar
  lib/             api client, parsing, storage, image helpers
scenarios/         end-to-end suite and showcase (see below)
.claude/skills/    project skills for working on the repo
docs/gaps.md       gap review: closed, open, and why
```

## How the prompt is organised

The model is not given one long prompt. `server/skills/` holds one Markdown module per concern, and `buildSystemPrompt` joins the ones a request needs: `core` (how to read marks, precedence), `rough` (messy sketches and photos), and `motion` (how to identify animation instructions) always; `create` or `adjust` by mode; `refine` when a previous result is attached; `output` always. Edit a rule in the Markdown, run `npm test`, then re-run the scenarios it affects.

### Rough sketches

A photo of a paper sketch is cleaned up before it is sent: uneven light and shadows are flattened, paper goes white, ink goes dark, and saturated colours are kept so a red note still reads as a note. The toolbar's "Clean photo" toggle turns it off. The `rough` module then tells the model how to read open boxes, scribbled-out marks, "x3" repeats, and illegible labels, and asks it to list anything it guessed under "Marks it wasn't sure about" in the Reading tab.

### Animation instructions

Motion can be drawn: a swooping arrow into position means slide in, a dashed ghost shape is a start state, a word on an arrow names the effect, a pointer with "hover" or a scroll glyph names the trigger. The `motion` module defines that vocabulary, classifies each instance by trigger (load, scroll, hover, click, loop), and implements it with CSS and a small IntersectionObserver, never leaving content hidden without JavaScript and always honouring reduced-motion. Every motion found is listed in the Reading tab.

## Checks

`npm run check` runs the typecheck and the parser tests. The scenario suite adds generated-output checks: a complete document, a title, a viewport meta, no lorem ipsum, every in-page link resolving, no external scripts or hotlinked images, reduced-motion respected, plus per-scenario expectations in `scenarios/scenarios-list.mjs`. Results are written to each scenario's `meta.json` and shown in the showcase.

## Scenario suite

`scenarios/` holds reproducible end-to-end tests: hand-drawn-style wireframes authored as SVG, each paired with a brief.

```bash
npm run dev:api            # the API must be running
npm run scenarios          # render sketches, run every scenario, build the showcase page
```

Or step by step: `npm run scenarios:render`, `npm run scenarios:run [id ...]`, `node scenarios/check.mjs`, `npm run scenarios:showcase`. Results land in `scenarios/out/<id>/` (sketch, result HTML, the model's analysis, timings, checks, screenshots) and `scenarios/out/showcase.html` collects them all on one page. Set `PROVIDER=api` or `MODEL=...` to run the same suite against a different backend. Earlier runs worth keeping go in `scenarios/out/_archive/`.

| Scenario | Exercises |
|---|---|
| `portfolio` | Labelled boxes, a 3x2 image grid, a styling note in red ink |
| `dashboard` | Sidebar, KPI tiles, chart, side list, data table |
| `recipe-app` | A portrait phone frame with notes placed outside it |
| `adjust-fernway` | Reordering, adding, and removing sections of an existing page |
| `ugly-photo` | A photographed ballpoint sketch with open boxes, a struck-out element, a stain and a crease, and four motion marks |
| `dashboard-refine` | A follow-up round with no new sketch, only a brief |

## Demo video and how-to screenshots

With the app running, `node scripts/record-demo.mjs` drives a real session with Playwright (draws a sketch, writes a brief, builds through the configured backend, tours the result) and writes `docs/media/demo-raw.webm`, the `step-*.png` screenshots, and the timings. `node scripts/condense-demo.mjs` then produces `docs/media/demo.webm` with the wait for the model compressed to about ten seconds, using the ffmpeg bundled with Playwright. Output is WebM (VP8); that ffmpeg build has no H.264 encoder.

## Reading your marks

| Mark | Read as |
|---|---|
| Box | A container or component; a word inside names it |
| Lines or squiggles | Text; a thicker line is a heading |
| Box with an X | Image or video |
| Circle | Avatar, icon, or round button |
| Arrow | Order, flow, or "move this here" |
| Red ink | A note to the model, not page content |
