import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { GenerateInput } from "./providers/types.js";

export const MARK_ANALYSIS = "<<<ANALYSIS>>>";
export const MARK_HTML = "<<<HTML>>>";
export const MARK_END = "<<<END>>>";

const skillsDir = path.join(path.dirname(fileURLToPath(import.meta.url)), "skills");

/** Prompt modules live as Markdown in server/skills so a rule can be edited without touching code. */
export type SkillName = "core" | "rough" | "motion" | "create" | "adjust" | "refine" | "output";

const skillCache = new Map<SkillName, string>();
export function loadSkill(name: SkillName): string {
  let text = skillCache.get(name);
  if (text === undefined) {
    text = readFileSync(path.join(skillsDir, `${name}.md`), "utf8").trim();
    skillCache.set(name, text);
  }
  return text;
}

export interface PromptShape {
  mode: "create" | "adjust";
  refining: boolean;
}

/** Which modules a request needs. Kept deterministic so the assembled prompt caches well. */
export function skillsFor(shape: PromptShape): SkillName[] {
  const list: SkillName[] = ["core", "rough", "motion", shape.mode === "adjust" ? "adjust" : "create"];
  if (shape.refining) list.push("refine");
  list.push("output");
  return list;
}

const promptCache = new Map<string, string>();
export function buildSystemPrompt(shape: PromptShape): string {
  const key = `${shape.mode}:${shape.refining ? "refine" : "fresh"}`;
  let text = promptCache.get(key);
  if (text === undefined) {
    text = skillsFor(shape)
      .map((s) => loadSkill(s))
      .join("\n\n");
    promptCache.set(key, text);
  }
  return text;
}

export function shapeOf(input: GenerateInput): PromptShape {
  return { mode: input.mode, refining: Boolean(input.previous) };
}

function clip(s: string, max: number): { text: string; clipped: boolean } {
  if (s.length <= max) return { text: s, clipped: false };
  return { text: s.slice(0, max), clipped: true };
}

/** Builds the text portion of the request (the image is attached separately by each provider). */
export function buildUserText(input: GenerateInput, opts: { imageRef?: string } = {}): string {
  const parts: string[] = [];

  if (opts.imageRef) {
    parts.push(
      `The doodle is the image file at: ${opts.imageRef}\nUse the Read tool to look at it before doing anything else.`,
    );
  } else if (input.imageDataUrl) {
    parts.push("The doodle is attached as an image.");
  } else if (input.previous) {
    parts.push("No new sketch this round. Work from the previous result and the brief below.");
  }

  parts.push(
    input.mode === "adjust"
      ? "Task: adjust the existing website so it matches the doodle and the brief."
      : "Task: create a new prototype from the doodle and the brief.",
  );

  const brief = input.instructions.trim();
  parts.push(`Brief from the user:\n${brief.length ? brief : "(none given; rely on the sketch)"}`);

  if (input.mode === "adjust") {
    const code = input.existingCode?.trim() ?? "";
    if (code.length) {
      const { text, clipped } = clip(code, 220_000);
      parts.push(
        `Existing website markup${input.existingSource ? ` (from ${input.existingSource})` : ""}${
          clipped ? " (truncated to the first 220,000 characters)" : ""
        }:\n<existing_site>\n${text}\n</existing_site>`,
      );
    } else {
      parts.push(
        "No existing markup was supplied. Treat this as a new prototype that should read as an adjustment of a conventional site of this kind.",
      );
    }
  }

  if (input.previous) {
    const { text, clipped } = clip(input.previous.html, 220_000);
    parts.push(
      `The previous brief was:\n${
        input.previous.instructions || "(empty)"
      }\n\nThe previous result was${clipped ? " (truncated)" : ""}:\n<previous_result>\n${text}\n</previous_result>`,
    );
  }

  return parts.join("\n\n");
}

export interface Analysis {
  summary?: string;
  regions?: { label?: string; placement?: string; component?: string; notes?: string }[];
  assumptions?: string[];
  changes?: string[];
  unclear?: { mark?: string; chosen?: string; alternative?: string }[];
  motion?: { element?: string; trigger?: string; effect?: string; duration?: string }[];
}

export interface ParsedOutput {
  analysis: Analysis | null;
  analysisRaw: string;
  html: string;
  complete: boolean;
}

/** Parses the model's marked output; tolerant of partial text so the UI can render while streaming. */
export function parseOutput(text: string): ParsedOutput {
  const a = text.indexOf(MARK_ANALYSIS);
  const h = text.indexOf(MARK_HTML);
  const e = text.indexOf(MARK_END);

  let analysisRaw = "";
  if (a !== -1) {
    const endA = h !== -1 ? h : text.length;
    analysisRaw = text.slice(a + MARK_ANALYSIS.length, endA).trim();
  }
  let html = "";
  if (h !== -1) {
    const endH = e !== -1 ? e : text.length;
    html = text.slice(h + MARK_HTML.length, endH).trim();
  } else if (a === -1) {
    const m = text.match(/<!doctype html>[\s\S]*<\/html>/i) ?? text.match(/<html[\s\S]*<\/html>/i);
    if (m) html = m[0];
  }
  html = html.replace(/^```[a-z]*\s*/i, "").replace(/\s*```$/, "");

  let analysis: Analysis | null = null;
  if (analysisRaw) {
    const cleaned = analysisRaw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
    try {
      analysis = JSON.parse(cleaned);
    } catch {
      analysis = null;
    }
  }
  return { analysis, analysisRaw, html, complete: e !== -1 };
}

export type ImageMediaType = "image/png" | "image/jpeg" | "image/webp" | "image/gif";

export function parseDataUrl(dataUrl: string): { mediaType: ImageMediaType; base64: string } {
  const m = dataUrl.match(/^data:(image\/(?:png|jpeg|webp|gif));base64,(.+)$/s);
  if (!m) throw new Error("Doodle must be a PNG, JPEG, WebP, or GIF data URL.");
  return { mediaType: m[1] as ImageMediaType, base64: m[2].replace(/\s/g, "") };
}
