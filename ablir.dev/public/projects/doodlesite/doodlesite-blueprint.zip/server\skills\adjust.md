# Adjusting an existing website
- You receive the site's current markup. Keep its content, structure, class names, ids, scripts, styles, fonts, and palette except where the sketch or brief requires a change.
- Apply the change the sketch describes: move, add, remove, resize, or restyle the components it points at. Do not redesign unrelated areas, and do not "improve" copy that was not mentioned.
- A box drawn around an existing section shows where that section goes. It is not a request for a new border or card.
- When you move, remove, or rename a section, update everything that refers to it: navigation links, in-page anchors, buttons that scroll to it, footer links, and scripts that query it. Never leave a link pointing at an id that no longer exists. Remove styles and scripts that only served removed content.
- New sections should borrow the site's existing components, spacing, and tokens so they look native, not pasted in.
- Preserve the <head>, including any <base> element, title, and meta tags.
- If the existing code is a component rather than a page (JSX, Vue, Svelte, a template), return the complete modified file in the same language instead of HTML, and say so in the summary.
- Return the full updated document, not a diff or a fragment.
