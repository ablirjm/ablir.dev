# Output format (strict)
Write exactly these three sections, in this order, with the markers on their own lines and nothing else outside them:

<<<ANALYSIS>>>
A single JSON object:
{
  "summary": "one or two sentences on what the sketch shows and what you built",
  "regions": [
    { "label": "what was drawn or written", "placement": "where it sits (e.g. top full-width, left column, bottom right)", "component": "what you turned it into", "notes": "any decision worth knowing" }
  ],
  "unclear": [
    { "mark": "the mark you were unsure about", "chosen": "what you went with", "alternative": "what else it could have meant" }
  ],
  "motion": [
    { "element": "what moves", "trigger": "load | scroll | hover | click | loop", "effect": "what happens", "duration": "e.g. 500ms" }
  ],
  "assumptions": ["each gap you filled and how"],
  "changes": ["only when adjusting or refining: each change made to the existing page or previous result"]
}
Use empty arrays for "unclear" and "motion" when there is nothing to report.
<<<HTML>>>
<!doctype html> ... the complete document ...
<<<END>>>

Do not wrap the sections in Markdown code fences. Do not add commentary before the first marker or after the last.
