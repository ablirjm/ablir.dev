---
name: doodle-scenarios
description: Run, extend, or interpret DoodleSite's end-to-end scenario suite (sketch plus brief through the real pipeline) and rebuild the showcase page. Use when asked to test DoodleSite, demo it, add a scenario, or check whether a change regressed generation quality.
---

# The scenario suite

`scenarios/` is the regression suite and the demo material at once. Each scenario is a wireframe drawn as SVG in a handwriting face, a brief, and a list of checks.

```
scenarios/
  doodles/*.html         sketches as SVG (shared look in _sketch.css)
  fixtures/              existing pages for adjust scenarios
  scenarios-list.mjs     id, title, mode, brief, checks, dependencies
  render.mjs             doodles -> out/<id>/doodle.png via headless Edge/Chrome
  run.mjs                posts each scenario to the local API, saves result + screenshots + meta
  check.mjs              generic and per-scenario assertions, written into meta.json
  showcase.mjs           builds out/showcase.html from everything above
  out/<id>/              doodle.png, result.html, analysis.json, meta.json, result-*.png
  out/_archive/          earlier runs kept for before/after comparison
```

## Running

The API must be up (`npm run dev:api`). Then:

- `npm run scenarios` for everything: render, run, showcase.
- `node scenarios/run.mjs <id ...>` for a subset. Independent scenarios run in parallel; a scenario with `previous` waits for its dependency.
- `node scenarios/check.mjs` re-evaluates checks on existing results without regenerating.
- `PROVIDER=api` or `MODEL=...` switch backends for a run; the showcase records which was used.

Budget 2 to 3 minutes per scenario on the CLI and about 4 parallel scenarios at a time.

## Adding a scenario

1. Copy an existing doodle in `scenarios/doodles/`, keep the `<filter id="rough" filterUnits="userSpaceOnUse" ...>` header, and draw with `rect`, `line`, `circle`, `path`, and `text`. Red ink (`class="note"`) means an instruction to the model.
2. Add an entry to `scenarios-list.mjs`: `id`, `title`, `tests` (one sentence on what it exercises), `mode`, `doodle`, `brief`, and `checks`. For adjust scenarios point `existing` at a fixture; for refinement rounds set `previous` to another scenario id and `doodle: null`.
3. Write checks as `{ name, test(html) -> true | "reason" }`. Prefer checks that would catch a regression you have actually seen over broad style opinions.
4. `node scenarios/render.mjs`, look at the PNG, then run the scenario.

## Reading results

- The summary table in the showcase shows time, time to first output, output size, regions read, and checks passed.
- A failing generic check (dangling anchors, external scripts, hotlinked images, missing reduced-motion rule) usually points at a prompt rule; a failing per-scenario check usually points at the sketch or brief being ambiguous. Decide which before editing anything.
- `analysis.json` is the model's own account of each mark. When it misreads a mark, the fix is in `server/skills/core.md`; when it reads correctly but builds the wrong thing, the fix is in `create.md` or `adjust.md`.

## Publishing the showcase

`node scenarios/showcase.mjs` writes a self-contained page (images inlined as data URIs, live prototypes embedded in sandboxed frames). Publish it with the Artifact tool, keeping the same file path so the URL is updated rather than duplicated.
