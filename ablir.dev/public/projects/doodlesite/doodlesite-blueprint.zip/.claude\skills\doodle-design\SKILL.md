---
name: doodle-design
description: The visual system of the DoodleSite app itself (palette, type, layout rules) and how to extend the UI without drifting from it. Use when adding or restyling any part of the React client or the showcase page.
---

# DoodleSite's visual system

The app is a drafting workbench. The one memorable element is the sheet: white paper with a non-photo-blue grid, the pencil colour that does not reproduce, so the grid is for the person and never reaches the model. Everything else sits quietly on hairline rules.

## Tokens (defined once at the top of `src/styles.css`)

| Token | Light | Dark | Use |
|---|---|---|---|
| `--paper` | #F2F3EF | #0E1620 | page ground |
| `--sheet` | #FFFFFF | #121D2A | the canvas, inputs, preview stage |
| `--ink` | #17212B | #E7ECF1 | text, drawn strokes |
| `--graphite` | #5E6975 | #9AA6B2 | secondary text |
| `--rule` / `--rule-strong` | #D3D8D2 / #B9C0BA | #22303F / #34465A | hairlines and borders |
| `--nonphoto` | #B8DDF0 | #1C3A52 | grid lines, guides |
| `--pen` | #1F4FD1 | #79A9FF | the single accent: primary action, active tool, focus ring |
| `--note` | #D8322B | #FF6B61 | annotation ink, errors |

Type is Bricolage Grotesque for everything, with JetBrains Mono only where the content is real code or data (token counts, character counts, times). The showcase page reuses the same tokens and adds `--ok` for passing checks.

## Rules

- No cards. Borders, shadows, and radius are spent by role: the sheet and the preview stage lift off the paper; nothing else does.
- Sentence case everywhere. No all-caps labels, no eyebrow labels, no numbered markers unless the content is a sequence.
- One accent. Semantic colours (pass, fail, warning) are separate from the accent and do not count as a second one.
- Motion only answers an action: the pencil line across the preview while generating, the pulse beside a status. No entrance animations.
- Both themes resolve through tokens. Never put a colour's only definition inside a media query.
- Copy is written from the user's side: "Build prototype", "Refine v3", "Draw or drop a sketch first." Errors say what went wrong and what to do.

## Adding a control

Use `.tool` for toolbar buttons (icon from `src/components/Icons.tsx`, 18px stroke icons), `.btn` for actions, `.btn.primary` for the one primary action per panel, `.segmented` for mutually exclusive modes. Keep the side gutter from `--gutter`; let rows wrap rather than shrink below the phone width.

## Checking a change

Headless Edge on Windows cannot open a window narrower than about 492px, so a "phone" screenshot at 420px is cropped, not laid out. Use 500px for the narrow check, or read the computed widths.
