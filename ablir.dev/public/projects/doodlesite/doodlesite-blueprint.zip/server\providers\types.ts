export type Mode = "create" | "adjust";

export interface HistoryItem {
  instructions: string;
  html: string;
}

export interface GenerateInput {
  /** PNG/JPEG data URL of the doodle, or null when iterating without a new sketch. */
  imageDataUrl: string | null;
  instructions: string;
  mode: Mode;
  /** Existing site markup when mode === "adjust". */
  existingCode?: string;
  /** Where the existing code came from (URL or "pasted"), for context only. */
  existingSource?: string;
  /** Previous round in this session, when refining. */
  previous?: HistoryItem;
}

export type ProviderEvent =
  | { type: "status"; message: string }
  | { type: "delta"; text: string }
  | { type: "done"; text: string; usage?: Record<string, unknown>; model?: string }
  | { type: "error"; message: string };

export interface ProviderSettings {
  provider: "api" | "claude-code";
  apiKey?: string;
  model?: string;
  cliBin: string;
}

export interface Provider {
  name: "api" | "claude-code";
  generate(
    input: GenerateInput,
    settings: ProviderSettings,
    emit: (e: ProviderEvent) => void,
    signal: AbortSignal,
  ): Promise<void>;
}
