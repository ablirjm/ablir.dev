import assert from "node:assert/strict";
import { test } from "node:test";
import {
  MARK_ANALYSIS,
  MARK_END,
  MARK_HTML,
  buildSystemPrompt,
  buildUserText,
  parseDataUrl,
  parseOutput,
  skillsFor,
} from "./prompt.js";

const doc = `<!doctype html>\n<html lang="en"><head><title>T</title></head><body><h1>Hi</h1></body></html>`;

test("parseOutput reads a complete marked response", () => {
  const text = `${MARK_ANALYSIS}\n{"summary":"s","regions":[{"label":"nav"}],"assumptions":["a"]}\n${MARK_HTML}\n${doc}\n${MARK_END}`;
  const out = parseOutput(text);
  assert.equal(out.complete, true);
  assert.equal(out.html, doc);
  assert.equal(out.analysis?.summary, "s");
  assert.equal(out.analysis?.regions?.length, 1);
});

test("parseOutput tolerates a partial stream", () => {
  const text = `${MARK_ANALYSIS}\n{"summary":"s"\n${MARK_HTML}\n<!doctype html><html><body><p>half`;
  const out = parseOutput(text);
  assert.equal(out.complete, false);
  assert.equal(out.analysis, null, "unfinished JSON is not parsed");
  assert.ok(out.html.startsWith("<!doctype html>"));
});

test("parseOutput strips code fences and falls back to a bare document", () => {
  const fenced = `${MARK_ANALYSIS}\n{}\n${MARK_HTML}\n\`\`\`html\n${doc}\n\`\`\`\n${MARK_END}`;
  assert.equal(parseOutput(fenced).html, doc);
  const bare = `Here you go:\n${doc}\nDone.`;
  assert.equal(parseOutput(bare).html, doc);
});

test("buildSystemPrompt assembles the modules a request needs", () => {
  assert.deepEqual(skillsFor({ mode: "create", refining: false }), ["core", "rough", "motion", "create", "output"]);
  assert.deepEqual(skillsFor({ mode: "adjust", refining: true }), ["core", "rough", "motion", "adjust", "refine", "output"]);

  const create = buildSystemPrompt({ mode: "create", refining: false });
  const adjust = buildSystemPrompt({ mode: "adjust", refining: false });
  const refine = buildSystemPrompt({ mode: "create", refining: true });

  assert.match(create, /Creating a new prototype/);
  assert.doesNotMatch(create, /Adjusting an existing website/);
  assert.match(adjust, /Never leave a link pointing at an id that no longer exists/);
  assert.doesNotMatch(adjust, /Refining a previous result/);
  assert.match(refine, /Refining a previous result/);
  for (const p of [create, adjust, refine]) {
    assert.ok(p.includes(MARK_ANALYSIS) && p.includes(MARK_HTML) && p.includes(MARK_END));
    assert.ok(p.startsWith("You turn rough layout sketches"));
    assert.match(p, /Reading a rough sketch/);
    assert.match(p, /Identifying animation instructions/);
    assert.match(p, /"motion": \[/);
    assert.match(p, /"unclear": \[/);
  }
  assert.equal(create, buildSystemPrompt({ mode: "create", refining: false }), "stable for prompt caching");
});

test("buildUserText includes what each mode needs", () => {
  const create = buildUserText({ imageDataUrl: "data:image/png;base64,AAAA", instructions: "Make it blue", mode: "create" });
  assert.match(create, /attached as an image/);
  assert.match(create, /Make it blue/);
  assert.doesNotMatch(create, /existing_site/);

  const adjust = buildUserText({
    imageDataUrl: null,
    instructions: "",
    mode: "adjust",
    existingCode: "<p>old</p>",
    existingSource: "https://x.test",
    previous: { instructions: "earlier", html: "<p>prev</p>" },
  });
  assert.match(adjust, /\(none given; rely on the sketch\)/);
  assert.match(adjust, /<existing_site>\n<p>old<\/p>\n<\/existing_site>/);
  assert.match(adjust, /from https:\/\/x\.test/);
  assert.match(adjust, /<previous_result>\n<p>prev<\/p>\n<\/previous_result>/);

  const cli = buildUserText({ imageDataUrl: "data:image/png;base64,AAAA", instructions: "x", mode: "create" }, { imageRef: "C:\\tmp\\d.png" });
  assert.match(cli, /Use the Read tool/);

  const big = buildUserText({ imageDataUrl: null, instructions: "x", mode: "adjust", existingCode: "a".repeat(300_000) });
  assert.match(big, /truncated to the first 220,000 characters/);
});

test("parseDataUrl accepts images and rejects anything else", () => {
  assert.deepEqual(parseDataUrl("data:image/jpeg;base64,/9j/4AAQ"), { mediaType: "image/jpeg", base64: "/9j/4AAQ" });
  assert.throws(() => parseDataUrl("data:text/html;base64,PGh0bWw+"));
});
