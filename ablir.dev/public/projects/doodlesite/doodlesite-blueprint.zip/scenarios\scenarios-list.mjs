// The scenario suite. Each entry is a sketch (scenarios/doodles/<doodle>.html) plus a brief, and
// optional `checks`: { name, test(html) -> true | "why it failed" }. Generic checks live in check.mjs.
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));

const count = (html, re) => (html.match(re) ?? []).length;
const before = (html, a, b) => {
  const ia = html.search(a);
  const ib = html.search(b);
  if (ia === -1) return `"${a.source ?? a}" not found`;
  if (ib === -1) return `"${b.source ?? b}" not found`;
  return ia < ib || "wrong order";
};

export const scenarios = [
  {
    id: "portfolio",
    title: "Photographer portfolio",
    tests: "Labelled boxes, a 3x2 image grid, and a styling note in red ink",
    mode: "create",
    doodle: "portfolio",
    brief:
      "Portfolio for Mara Lindqvist, a documentary wedding photographer in Gothenburg. Quiet and editorial. The six grid tiles are recent weddings; show the couple's names and the venue when you hover a tile. The hero photo is the most recent wedding.",
    checks: [
      { name: "Names the photographer", test: (h) => /Mara Lindqvist/.test(h) || "name missing" },
      {
        name: "At least six work tiles",
        test: (h) => {
          const grid = h.match(/<section[^>]*id="work"[\s\S]*?<\/section>/i)?.[0] ?? h;
          const n = Math.max(count(grid, /<(figure|article)\b/g), count(grid, /<a\b/g));
          return n >= 6 || `only ${n} tiles in the work section`;
        },
      },
      { name: "Hover reveals titles (red note)", test: (h) => /:hover/.test(h) || "no :hover rule" },
      { name: "Serif headline face (red note)", test: (h) => /serif/i.test(h) || "no serif family declared" },
    ],
  },
  {
    id: "dashboard",
    title: "Operations dashboard",
    tests: "App layout with sidebar, KPI tiles, chart, side list, and a data table",
    mode: "create",
    doodle: "dashboard",
    brief:
      "Operations dashboard for Pedalhub, a bike-share operator in Lyon. Used on big screens in the depot during the day. The chart is rides per hour for today; the table is the last few rides with station, duration, and fare. Use believable numbers for a city of 500 bikes.",
    checks: [
      { name: "Names the product", test: (h) => /Pedalhub/.test(h) || "name missing" },
      { name: "Recent rides is a real table", test: (h) => /<table\b/i.test(h) || "no <table>" },
      { name: "Chart drawn with SVG or canvas", test: (h) => /<(svg|canvas)\b/i.test(h) || "no drawing element" },
      {
        name: "Five sidebar links as drawn",
        test: (h) => {
          const nav = h.match(/<nav[\s\S]*?<\/nav>/i)?.[0] ?? "";
          const n = count(nav, /<a\b/g);
          return n >= 5 || `${n} links in the first <nav>`;
        },
      },
    ],
  },
  {
    id: "recipe-app",
    title: "Phone-only recipe app",
    tests: "A portrait phone frame, chips, cards, a bottom tab bar, and notes placed outside the frame",
    mode: "create",
    doodle: "recipe-app",
    brief:
      "Home screen of Simmer, a weeknight recipe app. Render it as a single phone-width screen centred on the page, not a desktop website. Tonight's pick is a 25-minute miso salmon. The chips filter by time and diet.",
    note:
      "First run: the tab bar linked to #home, #plan and #saved with no such elements on the page. A rule in create.md now requires every in-page link to resolve; the re-run links only to sections that exist.",
    checks: [
      { name: "Tonight's pick is the miso salmon", test: (h) => /miso/i.test(h) || "no miso salmon" },
      { name: "Constrained to phone width", test: (h) => /(max-)?width:\s*(3[6-9]\d|4[0-3]\d)px/.test(h) || "no 360-439px frame width" },
      { name: "Four tab bar items", test: (h) => count(h, /tab/gi) >= 4 || "fewer than four tab mentions" },
    ],
  },
  {
    id: "adjust-fernway",
    title: "Adjust an existing site",
    tests: "Reordering sections of a real page, adding one, removing one, and keeping the rest untouched",
    mode: "adjust",
    doodle: "adjust-fernway",
    existing: path.join(here, "fixtures", "fernway.html"),
    brief:
      "Move the three plan cards directly under the nav so pricing is the first thing people see, with the hero below them. Add a short reviews strip with three customer quotes between the hero and the footer. Remove the 'How it works' section. Keep the nav, the plan cards themselves, the palette, and the footer exactly as they are.",
    note:
      "First run removed the section but left the 'How it works' nav link and hero button pointing at #how, and boxed the hero because the sketch drew a box around it. adjust.md now requires references to be updated when a section moves or goes, and core.md reads a box around a whole band as a section boundary. The re-run retargets both links to the reviews section and removes the orphaned CSS.",
    checks: [
      { name: "Plans now sit above the hero", test: (h) => before(h, /Sprout/, /A new houseplant/) },
      { name: "'How it works' gone everywhere, links included", test: (h) => !/How it works/i.test(h) || "still mentioned (a leftover nav link, most likely)" },
      { name: "Reviews strip added", test: (h) => /review/i.test(h) || "no reviews section" },
      { name: "All three plans kept", test: (h) => (/Sprout/.test(h) && /Canopy/.test(h) && /Jungle/.test(h)) || "a plan went missing" },
      { name: "Palette kept (forest green)", test: (h) => /#1B7A3E/i.test(h) || "original green not found" },
      { name: "Nav call to action kept", test: (h) => /Start a subscription/.test(h) || "nav button changed" },
    ],
  },
  {
    id: "ugly-photo",
    title: "Rough ballpoint sketch, photographed",
    tests:
      "Open boxes, a struck-out element, half-legible labels, a crease, a stain, and uneven light, plus motion marks: a slide-in arrow, a fade label, a hover note, and a scroll reveal",
    mode: "create",
    doodle: "ugly-photo",
    clean: true,
    brief: "Spoke & Chain, a bike repair workshop in Leeds. One page.",
    note:
      "The photo is cleaned before it is sent (grey paper, shadow, crease and stain removed; the red note keeps its colour). First run: the struck-out button was drawn with X lines, which the rough-sketch rule itself defines as an image placeholder, so the model kept it as a hover thumbnail. The sketch now uses a dense scribble, and the re-run reports it as 'Omitted, read as a deleted secondary button' and moves the hover lift to the Book now button where the arrow points. All four motion marks were found with the right trigger both times.",
    checks: [
      { name: "Names the shop", test: (h) => /Spoke/.test(h) || "shop name missing" },
      {
        name: "Three service cards (uneven boxes, 'x3')",
        test: (h) => {
          const n = Math.max(count(h, /<article\b/g), count(h, /class="[^"]*\bcard\b[^"]*"/g), count(h, /class="[^"]*\bservice\b[^"]*"/g));
          return n >= 3 || `found ${n} card-like elements`;
        },
      },
      {
        name: "Scribbled-out second button recognised as deleted",
        test: (_h, a) => {
          // One sentence must say the scribbled mark was left out; "scribbled" in one place and "omit" in
          // another is not evidence.
          // Each region / unclear entry is judged as one unit (label + component + notes).
          const strings = [];
          const walk = (v) => {
            if (typeof v === "string") strings.push(v);
            else if (Array.isArray(v)) v.forEach(walk);
            else if (v && typeof v === "object") {
              const own = Object.values(v).filter((x) => typeof x === "string");
              if (own.length) strings.push(own.join(" "));
              Object.values(v).filter((x) => x && typeof x === "object").forEach(walk);
            }
          };
          walk(a ?? {});
          const hit = strings.some(
            (s) => /scribbl|struck|crossed[- ]out|scratched/i.test(s) && /(omit|delet|remov|dropp|left out|ignor|not (built|rendered|included|a button))/i.test(s),
          );
          return hit || "no sentence in the analysis says the scribbled-out mark was left out";
        },
      },
      {
        name: "Only one hero button",
        test: (h) => {
          const hero = h.match(/<(section|header|div)[^>]*class="[^"]*hero[^"]*"[\s\S]*?<\/\1>/i)?.[0] ?? "";
          const n = (hero.match(/class="[^"]*\bbtn\b[^"]*"|<button\b/g) ?? []).length;
          return hero === "" || n <= 1 || `${n} buttons in the hero; the scribbled one should be gone`;
        },
      },
      {
        name: "Four motion instructions found",
        test: (_h, a) => (Array.isArray(a?.motion) && a.motion.length >= 3) || `${a?.motion?.length ?? 0} motion entries (expected slide-in, fade, hover, scroll)`,
      },
      { name: "Hero entrance implemented", test: (h) => /@keyframes/.test(h) || "no keyframes" },
      { name: "Hover lift on the button", test: (h) => (/:hover/.test(h) && /translate|scale/.test(h)) || "no hover transform" },
      { name: "Scroll reveal implemented", test: (h) => /IntersectionObserver/.test(h) || "no IntersectionObserver" },
      {
        name: "Unclear marks reported",
        test: (_h, a) => (Array.isArray(a?.unclear) && a.unclear.length >= 1) || "no unclear entries despite the '?' and scribbles",
      },
      { name: "Red margin note kept off the page", test: (h) => !/workshop feel/i.test(h) || "the note was rendered as content" },
    ],
  },
  {
    id: "dashboard-refine",
    title: "Refinement round, no new sketch",
    tests: "Iterating on a previous result from the brief alone",
    mode: "create",
    doodle: null,
    previous: "dashboard",
    brief:
      "Keep the layout. Switch to a dark theme suited to a depot wall screen, add a date range control to the top bar in place of 'today', make the table columns sortable by clicking the header, and highlight any ride longer than 45 minutes.",
    checks: [
      { name: "Still Pedalhub", test: (h) => /Pedalhub/.test(h) || "name missing" },
      { name: "Sortable table headers", test: (h) => /sort/i.test(h) || "no sorting code" },
      { name: "Date range control", test: (h) => /type="date"|date.?range/i.test(h) || "no date control" },
      { name: "Long rides highlighted", test: (h) => /45/.test(h) || "no 45-minute threshold" },
      { name: "Layout kept (sidebar, table, chart)", test: (h) => (/<nav\b/i.test(h) && /<table\b/i.test(h) && /<(svg|canvas)\b/i.test(h)) || "a region disappeared" },
    ],
  },
];
