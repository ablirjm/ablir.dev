import "dotenv/config";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { existsSync } from "node:fs";
import { checkCli, describeModel, getProvider, resolveSettings } from "./providers/index.js";
import { parseOutput } from "./prompt.js";
import type { GenerateInput, ProviderEvent } from "./providers/types.js";

const app = express();
const PORT = Number(process.env.PORT) || 8787;
const here = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "40mb" }));

function overridesFrom(req: express.Request) {
  const header = (name: string) => {
    const v = req.header(name);
    return typeof v === "string" && v.length ? v : undefined;
  };
  return {
    provider: header("x-doodle-provider"),
    apiKey: header("x-doodle-api-key"),
    model: header("x-doodle-model"),
  };
}

app.get("/api/health", async (req, res) => {
  const cfg = await resolveSettings(overridesFrom(req));
  const cli = await checkCli(cfg.cliBin);
  res.json({
    provider: cfg.provider,
    source: cfg.source,
    model: describeModel(cfg),
    apiKeyConfigured: Boolean(cfg.apiKey),
    apiKeyFromEnv: Boolean(process.env.ANTHROPIC_API_KEY?.trim()),
    cli: { bin: cfg.cliBin, ...cli },
  });
});

/** Loopback, link-local, and RFC 1918 hosts; the fetch endpoint refuses them unless explicitly allowed. */
function isPrivateHost(host: string): boolean {
  const h = host.toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h === "::1" || h.startsWith("fe80:") || h.startsWith("fc") || h.startsWith("fd")) return true;
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (!m) return false;
  const [a, b] = [Number(m[1]), Number(m[2])];
  return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

/** Fetches a public page so it can be adjusted. Adds a <base> so relative assets keep working in the preview. */
app.post("/api/fetch-site", async (req, res) => {
  const raw = String(req.body?.url ?? "").trim();
  let url: URL;
  try {
    url = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
  } catch {
    res.status(400).json({ error: "That does not look like a URL." });
    return;
  }
  if (!/^https?:$/.test(url.protocol)) {
    res.status(400).json({ error: "Only http and https URLs can be fetched." });
    return;
  }
  if (isPrivateHost(url.hostname) && process.env.DOODLE_ALLOW_PRIVATE_FETCH !== "1") {
    res.status(400).json({
      error: "That address is on a private network. Paste the markup instead, or set DOODLE_ALLOW_PRIVATE_FETCH=1 to allow it.",
    });
    return;
  }
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20_000);
    const r = await fetch(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: { "user-agent": "Mozilla/5.0 (compatible; DoodleSite/0.1)", accept: "text/html,*/*" },
    });
    clearTimeout(timer);
    if (!r.ok) {
      res.status(502).json({ error: `The site answered with HTTP ${r.status}.` });
      return;
    }
    let html = await r.text();
    if (!/<base\s/i.test(html)) {
      const base = `<base href="${r.url}">`;
      html = /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, (m) => `${m}\n${base}`) : `${base}\n${html}`;
    }
    res.json({ html, finalUrl: r.url, bytes: html.length });
  } catch (err) {
    res.status(502).json({ error: `Could not fetch that page: ${err instanceof Error ? err.message : String(err)}` });
  }
});

app.post("/api/generate", async (req, res) => {
  const body = req.body as Partial<GenerateInput> | undefined;
  if (!body || (body.mode !== "create" && body.mode !== "adjust")) {
    res.status(400).json({ error: "mode must be 'create' or 'adjust'." });
    return;
  }
  if (!body.imageDataUrl && !body.previous) {
    res.status(400).json({ error: "Draw or upload a doodle first." });
    return;
  }
  const input: GenerateInput = {
    imageDataUrl: body.imageDataUrl ?? null,
    instructions: String(body.instructions ?? ""),
    mode: body.mode,
    existingCode: body.existingCode ? String(body.existingCode) : undefined,
    existingSource: body.existingSource ? String(body.existingSource) : undefined,
    previous: body.previous && typeof body.previous.html === "string"
      ? { html: body.previous.html, instructions: String(body.previous.instructions ?? "") }
      : undefined,
  };

  const cfg = await resolveSettings(overridesFrom(req));
  const provider = getProvider(cfg.provider);

  res.writeHead(200, {
    "content-type": "text/event-stream; charset=utf-8",
    "cache-control": "no-cache, no-transform",
    connection: "keep-alive",
    "x-accel-buffering": "no",
  });
  res.flushHeaders?.();

  const controller = new AbortController();
  req.on("close", () => controller.abort());

  const send = (e: ProviderEvent | { type: "result"; [k: string]: unknown }) => {
    if (res.writableEnded) return;
    res.write(`data: ${JSON.stringify(e)}\n\n`);
  };
  const heartbeat = setInterval(() => {
    if (!res.writableEnded) res.write(": keep-alive\n\n");
  }, 15_000);

  send({ type: "status", message: `Using ${cfg.provider === "api" ? "the Anthropic API" : "local Claude Code"} (${describeModel(cfg)})` });

  try {
    await provider.generate(
      input,
      cfg,
      (e) => {
        if (e.type === "done") {
          const parsed = parseOutput(e.text);
          if (!parsed.html) {
            send({
              type: "error",
              message: "The model finished without producing an HTML document. Try again, or add more detail to the brief.",
            });
          } else {
            send({ type: "result", ...parsed, usage: e.usage, model: e.model, provider: cfg.provider });
          }
        } else {
          send(e);
        }
      },
      controller.signal,
    );
  } catch (err) {
    send({ type: "error", message: err instanceof Error ? err.message : String(err) });
  } finally {
    clearInterval(heartbeat);
    if (!res.writableEnded) res.end();
  }
});

// Serve the built client in production.
const dist = path.resolve(here, "..", "dist");
if (existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(path.join(dist, "index.html")));
}

app.listen(PORT, () => {
  console.log(`DoodleSite API listening on http://localhost:${PORT}`);
});
