# Gap review, 11 October 2026

What the first build and the first scenario run exposed, what was done about it, and what is deliberately left open. Each row names where the fix lives so it can be checked rather than trusted.

## Closed in this pass

| Gap | Evidence | Fix | Where |
|---|---|---|---|
| Removing a section left links pointing at it | adjust-fernway run 1: nav still linked `#how` | Rule: update every reference when a section moves, goes, or is renamed; remove orphaned styles and scripts | `server/skills/adjust.md`, check "Every in-page link resolves" |
| A box drawn around a whole band was rendered as a visible card | adjust-fernway run 1 boxed the hero | Rule: a box enclosing a full-width band is a section boundary, not a border | `server/skills/core.md` |
| App-style prototypes linked tabs to screens that did not exist | recipe-app run 1: `#home`, `#plan`, `#saved` had no targets | Rule: link only to sections you built; checks treat `#a/b` hashes as routes | `server/skills/create.md`, `scenarios/check.mjs` |
| One monolithic system prompt for three different jobs | create rules were sent on adjust requests and vice versa | Prompt assembled from Markdown modules per mode; cached per shape so API prompt caching still hits | `server/prompt.ts`, `server/skills/` |
| No way to know whether a prompt change helped | the suite was a showcase, not a test | Generic and per-scenario checks written into `meta.json`, shown in the showcase, and run automatically after each scenario | `scenarios/check.mjs`, `scenarios/scenarios-list.mjs` |
| No unit tests on the parsers that everything depends on | a marker regression would have gone unnoticed | `node:test` suite over `parseOutput`, `buildUserText`, `buildSystemPrompt`, `parseDataUrl` | `server/prompt.test.ts`, `npm test` |
| CLI provider would break for users whose profile path has a space | `shell: true` on Windows does not quote arguments | Arguments with spaces are quoted before spawn | `server/providers/claudeCode.ts` |
| URL fetch could reach localhost and private networks | any URL was accepted | Loopback, link-local, and RFC 1918 hosts are refused unless `DOODLE_ALLOW_PRIVATE_FETCH=1` | `server/index.ts` |
| A page reload lost the sketch and every version | state lived only in React | Strokes, sheet size, background photo, and the last 20 versions persist in localStorage with quota fallbacks | `src/lib/storage.ts`, `SketchPanel`, `App` |
| Landscape-only sheet made phone layouts awkward | recipe-app sketch wasted two thirds of the sheet | Portrait sheet toggle (800 x 1200); the sheet now keeps its true aspect ratio at every viewport | `SketchPanel` |
| Component code results were "previewed" as broken pages | JSX passed the renderability test | Only real documents are previewed; otherwise the stage explains and points to the Code tab | `PreviewPane` |
| No record of what a refinement round changed | reader had to diff two pages | `changes` list in the analysis for adjust and refine rounds, shown in the Reading tab and the showcase | `server/skills/output.md`, `PreviewPane` |
| No sketch export, no token usage | | PNG export of the sheet; input and output tokens on each version | `SketchPanel`, `PreviewPane` |
| Knowledge of how to work on this lived in one chat | | `CLAUDE.md` plus three project skills: `doodle-prompt`, `doodle-scenarios`, `doodle-design` | `.claude/skills/` |
| Messy or photographed sketches were read literally | no scenario covered open boxes, scribbles, stains, shadows | Client clean-up handler (background flattening, contrast, hue kept for notes) plus the `rough` module and an `unclear` list in the analysis | `src/lib/photo-core.js`, `server/skills/rough.md`, scenario `ugly-photo` |
| No way to ask for animation in a sketch | motion marks had no defined meaning | `motion` module: mark vocabulary, trigger classification, safe implementation; `motion` list in the analysis; checks for keyframes, hover transforms, scroll reveal, and no content hidden without a ready state | `server/skills/motion.md`, `scenarios/check.mjs` |

## Open, with a position on each

| Gap | Why it is open | Suggested shape |
|---|---|---|
| A second image as a style reference | Briefs can describe a brand but not show one | Optional "reference" image slot sent as a second image block; CLI provider writes a second file |
| Multiple sketches per request (desktop and phone of the same page) | One sheet per round today | Sheet tabs, each exported and labelled in the prompt |
| Output as React or Vue components | Only self-contained HTML is produced | A "target" setting that swaps `create.md` for a framework module and disables the preview |
| Diff view between versions | Reader compares screenshots by eye | Side-by-side frames plus a text diff of the HTML |
| Check depth | Checks are regexes over HTML | Render each result headlessly and assert on layout (region order, widths) and console errors |
| Long sessions and quota | Versions are capped at 20 in localStorage | IndexedDB store with export and import |
| Hooks and settings leaking into the CLI run | The spawned CLI inherits user settings | Pass `--setting-sources` once its behaviour with an empty list is confirmed |
| Headless screenshots narrower than 492px | Windows window minimum | Device emulation through a driver such as Playwright |

## Skills, organised

Two layers, deliberately separate:

- **The generator's skills** are the prompt modules in `server/skills/`. They are what the model is told. They change when results are wrong.
- **The project's skills** are in `.claude/skills/`. They are what a person or an agent working on the repo needs to know. They change when the way of working changes.

The design reference this project was built against is the `frontend-design` skill from the official plugin marketplace. `impeccable` was requested but is not installed on this machine; its spirit (no templated defaults, deliberate typography, restraint) is folded into `doodle-design` and `create.md`.
