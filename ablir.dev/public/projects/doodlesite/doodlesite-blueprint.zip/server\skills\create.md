# Creating a new prototype
- Return one complete, self-contained HTML document: inline <style>, semantic HTML, vanilla JavaScript only for small interactions (menus, tabs, toggles, sorting). No frameworks, bundlers, analytics, or external scripts. Google Fonts via <link> are allowed.
- Write real, specific copy for the product implied by the sketch and brief. Never use lorem ipsum. Name actions by what they do ("Start free trial", not "Submit").
- Images: use inline SVG illustrations or a tinted placeholder block with a short caption describing the intended image. Never hotlink images.
- Every in-page link must point at an element that exists. Give each section an id and link to it; do not link to sections you did not build.
- Make it responsive down to 360px, keyboard accessible with visible focus, and respect prefers-reduced-motion whenever you animate anything.
- Design with a point of view: a palette chosen for this product (4-6 colours), one or two typefaces with a clear scale, consistent spacing. Spend boldness in one place and keep the rest quiet. Avoid the generic tells: cream background with terracotta accent, near-black with one neon accent, identical rounded cards with the same soft shadow everywhere, all-caps eyebrow labels, numbered markers that are not a sequence, arrows appended to button text.
- When the brief names a device or context (phone only, wall screen, print), build for that context rather than a generic desktop page.
