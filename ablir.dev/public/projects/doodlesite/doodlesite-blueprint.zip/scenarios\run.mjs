// Runs the scenario suite against a local DoodleSite API and records results under scenarios/out/<id>/.
//
//   node scenarios/run.mjs              run everything (independent scenarios in parallel)
//   node scenarios/run.mjs dashboard    run one scenario (and whatever it depends on, if missing)
//   PROVIDER=api node scenarios/run.mjs override the provider for this run
//
// Each scenario folder ends up with: doodle.png (input), result.html, analysis.json, meta.json,
// result-desktop.png, result-phone.png.
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { screenshot } from "./render.mjs";
import { scenarios } from "./scenarios-list.mjs";
import { checkScenario } from "./check.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const API = process.env.DOODLE_API ?? "http://localhost:8787";
const out = (id, f = "") => path.join(here, "out", id, f);

export { scenarios };

async function runScenario(s) {
  const started = Date.now();
  mkdirSync(out(s.id), { recursive: true });
  const body = { mode: s.mode, instructions: s.brief, imageDataUrl: null };
  if (s.doodle) {
    const png = out(s.doodle, s.clean ? "doodle-clean.png" : "doodle.png");
    if (!existsSync(png)) throw new Error(`Missing ${png}; run node scenarios/render.mjs first`);
    body.imageDataUrl = `data:image/png;base64,${readFileSync(png).toString("base64")}`;
  }
  if (s.existing) {
    body.existingCode = readFileSync(s.existing, "utf8");
    body.existingSource = path.basename(s.existing);
  }
  if (s.previous) {
    const prevHtml = out(s.previous, "result.html");
    if (!existsSync(prevHtml)) throw new Error(`Scenario ${s.id} needs ${s.previous} to have run first`);
    const prev = scenarios.find((x) => x.id === s.previous);
    body.previous = { instructions: prev?.brief ?? "", html: readFileSync(prevHtml, "utf8") };
  }

  const headers = { "content-type": "application/json" };
  if (process.env.PROVIDER) headers["x-doodle-provider"] = process.env.PROVIDER;
  if (process.env.MODEL) headers["x-doodle-model"] = process.env.MODEL;

  const r = await fetch(`${API}/api/generate`, { method: "POST", headers, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`${s.id}: HTTP ${r.status} ${await r.text()}`);

  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  let result = null;
  let error = null;
  const statuses = [];
  let deltas = 0;
  let firstDeltaAt = null;
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf("\n\n")) !== -1) {
      const frame = buf.slice(0, i);
      buf = buf.slice(i + 2);
      for (const line of frame.split("\n")) {
        if (!line.startsWith("data:")) continue;
        const ev = JSON.parse(line.slice(5));
        if (ev.type === "delta") {
          deltas++;
          firstDeltaAt ??= Date.now();
        } else if (ev.type === "status") statuses.push(ev.message);
        else if (ev.type === "error") error = ev.message;
        else if (ev.type === "result") result = ev;
      }
    }
  }
  const seconds = Math.round((Date.now() - started) / 1000);
  if (!result) throw new Error(`${s.id}: ${error ?? "no result"} (after ${seconds}s)`);

  writeFileSync(out(s.id, "result.html"), result.html);
  writeFileSync(out(s.id, "analysis.json"), JSON.stringify(result.analysis ?? { raw: result.analysisRaw }, null, 2));
  const meta = {
    id: s.id,
    title: s.title,
    tests: s.tests,
    mode: s.mode,
    brief: s.brief,
    doodle: s.doodle,
    cleaned: Boolean(s.clean),
    previous: s.previous ?? null,
    existing: s.existing ? path.basename(s.existing) : null,
    provider: result.provider,
    model: result.model,
    complete: result.complete,
    htmlChars: result.html.length,
    seconds,
    secondsToFirstToken: firstDeltaAt ? Math.round((firstDeltaAt - started) / 1000) : null,
    statuses,
    ranAt: new Date().toISOString(),
  };
  writeFileSync(out(s.id, "meta.json"), JSON.stringify(meta, null, 2));

  const url = pathToFileURL(out(s.id, "result.html")).href;
  screenshot(url, out(s.id, "result-desktop.png"), { width: 1440, height: 1000 });
  screenshot(url, out(s.id, "result-phone.png"), { width: 500, height: 1000 });
  const checks = checkScenario(s) ?? [];
  const failed = checks.filter((c) => !c.pass);
  console.log(
    `${failed.length ? "✗" : "✓"} ${s.id}: ${result.html.length} chars in ${seconds}s, checks ${checks.length - failed.length}/${checks.length}`,
  );
  for (const f of failed) console.log(`    ${f.name}: ${f.detail}`);
  return JSON.parse(readFileSync(out(s.id, "meta.json"), "utf8"));
}

const only = process.argv.slice(2);
const wanted = only.length ? scenarios.filter((s) => only.includes(s.id)) : scenarios;
const done = new Set();
const results = [];
// Run in waves: everything whose dependencies are satisfied runs in parallel.
let pending = [...wanted];
while (pending.length) {
  const wave = pending.filter((s) => !s.previous || done.has(s.previous) || existsSync(out(s.previous, "result.html")));
  if (!wave.length) throw new Error(`Unmet dependencies for: ${pending.map((s) => s.id).join(", ")}`);
  console.log(`running: ${wave.map((s) => s.id).join(", ")}`);
  const settled = await Promise.allSettled(wave.map(runScenario));
  settled.forEach((r, i) => {
    if (r.status === "fulfilled") {
      results.push(r.value);
      done.add(wave[i].id);
    } else {
      console.error(`✗ ${wave[i].id}: ${r.reason?.message ?? r.reason}`);
      results.push({ id: wave[i].id, error: String(r.reason?.message ?? r.reason) });
    }
  });
  pending = pending.filter((s) => !wave.includes(s));
}
writeFileSync(path.join(here, "out", "summary.json"), JSON.stringify(results, null, 2));
console.log(`summary written to scenarios/out/summary.json`);
