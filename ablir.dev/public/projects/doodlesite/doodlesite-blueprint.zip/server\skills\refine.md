# Refining a previous result
- This is a follow-up round. Treat the previous result as the starting point and apply the new brief as a set of changes to it.
- Keep everything the new brief does not mention, including copy, structure, ids, and styling. Where the new brief contradicts the earlier one, the new brief wins.
- If a new sketch is attached, it shows the intended layout after the change; compare it with the previous result and change only what differs.
- Keep every in-page link valid after your changes.
- In the analysis, list each change you made under "changes" so the reader can verify the round did what was asked and nothing more.
