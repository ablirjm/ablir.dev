import { spawn } from "node:child_process";
import { mkdir, writeFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { buildSystemPrompt, buildUserText, parseDataUrl, shapeOf, MARK_HTML } from "../prompt.js";
import type { Provider } from "./types.js";

const isWin = process.platform === "win32";

/**
 * Drives the locally installed Claude Code CLI in print mode.
 * The doodle is written to a temp file and the CLI is limited to the Read tool so it can look at it.
 * Uses whatever login the user already has in Claude Code (no API key needed).
 */
export const claudeCodeProvider: Provider = {
  name: "claude-code",
  async generate(input, settings, emit, signal) {
    const workDir = path.join(os.tmpdir(), "doodlesite", randomUUID());
    await mkdir(workDir, { recursive: true });

    let imageRef: string | undefined;
    if (input.imageDataUrl) {
      const { mediaType, base64 } = parseDataUrl(input.imageDataUrl);
      const ext = mediaType === "image/jpeg" ? "jpg" : mediaType.split("/")[1];
      imageRef = path.join(workDir, `doodle.${ext}`);
      await writeFile(imageRef, Buffer.from(base64, "base64"));
    }
    const systemPath = path.join(workDir, "system.md");
    await writeFile(systemPath, buildSystemPrompt(shapeOf(input)), "utf8");

    const userText = buildUserText(input, { imageRef });

    const args = [
      "-p",
      "--output-format",
      "stream-json",
      "--verbose",
      "--include-partial-messages",
      "--no-session-persistence",
      "--tools",
      "Read",
      "--allowedTools",
      "Read",
      "--max-turns",
      "6",
      "--system-prompt-file",
      systemPath,
    ];
    if (settings.model?.trim()) args.push("--model", settings.model.trim());

    emit({ type: "status", message: `Starting the local Claude Code CLI (${settings.cliBin})` });

    // On Windows the CLI is a .cmd shim, so it has to go through the shell, and the shell does not
    // quote arguments for us. Paths with spaces (most user profiles) would otherwise split.
    const spawnArgs = isWin ? args.map((a) => (/[\s"]/.test(a) ? `"${a.replace(/"/g, '\\"')}"` : a)) : args;

    const child = spawn(settings.cliBin, spawnArgs, {
      cwd: workDir,
      shell: isWin,
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: "1" },
      windowsHide: true,
    });

    const onAbort = () => {
      try {
        child.kill();
      } catch {
        /* ignore */
      }
    };
    signal.addEventListener("abort", onAbort, { once: true });

    const state = {
      streamed: "",
      resultText: null as string | null,
      resultError: null as string | null,
      usage: undefined as Record<string, unknown> | undefined,
      stderr: "",
      announcedWriting: false,
      buffer: "",
    };

    const handleLine = (line: string) => {
      if (!line.trim()) return;
      let msg: any;
      try {
        msg = JSON.parse(line);
      } catch {
        return;
      }
      switch (msg.type) {
        case "system":
          if (msg.subtype === "init") emit({ type: "status", message: `Claude Code ready (${msg.model ?? "default model"})` });
          break;
        case "stream_event": {
          const ev = msg.event;
          if (ev?.type === "content_block_start" && ev.content_block?.type === "tool_use") {
            emit({ type: "status", message: "Looking at the sketch" });
          }
          if (ev?.type === "content_block_delta" && ev.delta?.type === "text_delta") {
            state.streamed += ev.delta.text;
            if (!state.announcedWriting && state.streamed.includes(MARK_HTML)) {
              state.announcedWriting = true;
              emit({ type: "status", message: "Writing the prototype" });
            }
            emit({ type: "delta", text: ev.delta.text });
          }
          break;
        }
        case "result":
          if (msg.is_error) {
            state.resultError =
              typeof msg.result === "string" ? msg.result : (msg.subtype ?? "Claude Code reported an error");
          } else if (typeof msg.result === "string") {
            state.resultText = msg.result;
          }
          if (msg.usage && typeof msg.usage === "object") state.usage = msg.usage;
          break;
        default:
          break;
      }
    };

    child.stdout.setEncoding("utf8");
    child.stdout.on("data", (chunk: string) => {
      state.buffer += chunk;
      let idx: number;
      while ((idx = state.buffer.indexOf("\n")) !== -1) {
        handleLine(state.buffer.slice(0, idx));
        state.buffer = state.buffer.slice(idx + 1);
      }
    });
    child.stderr.setEncoding("utf8");
    child.stderr.on("data", (chunk: string) => {
      state.stderr += chunk;
    });

    const exit = new Promise<{ code: number | null; error?: Error }>((resolve) => {
      child.once("error", (error) => resolve({ code: null, error }));
      child.once("close", (code) => resolve({ code }));
    });

    child.stdin.on("error", () => {
      /* child may exit before reading stdin; surfaced via exit code */
    });
    child.stdin.end(userText);

    const { code, error } = await exit;
    if (state.buffer.trim()) handleLine(state.buffer);
    signal.removeEventListener("abort", onAbort);
    rm(workDir, { recursive: true, force: true }).catch(() => undefined);

    if (signal.aborted) return;

    if (error) {
      const notFound = (error as NodeJS.ErrnoException).code === "ENOENT";
      emit({
        type: "error",
        message: notFound
          ? `Could not start "${settings.cliBin}". Install Claude Code or set CLAUDE_CODE_BIN to its path.`
          : `Could not start Claude Code: ${error.message}`,
      });
      return;
    }
    if (state.resultError) {
      emit({ type: "error", message: `Claude Code: ${state.resultError}` });
      return;
    }
    // Prefer the full final result when it carries the markers; otherwise use what we streamed.
    const { resultText, streamed } = state;
    const text = resultText && resultText.includes(MARK_HTML) ? resultText : streamed || resultText || "";
    if (!text.trim()) {
      const hint = state.stderr.trim().split("\n").slice(-3).join(" ");
      emit({
        type: "error",
        message: `Claude Code exited (code ${code ?? "?"}) without a result.${
          hint ? ` ${hint}` : " Run \"claude\" once in a terminal to make sure you are logged in."
        }`,
      });
      return;
    }
    emit({ type: "done", text, usage: state.usage, model: settings.model || "claude-code default" });
  },
};
