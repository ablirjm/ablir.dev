import Anthropic from "@anthropic-ai/sdk";
import { buildSystemPrompt, buildUserText, parseDataUrl, shapeOf } from "../prompt.js";
import type { Provider } from "./types.js";

export const DEFAULT_API_MODEL = "claude-opus-5";

export const apiProvider: Provider = {
  name: "api",
  async generate(input, settings, emit, signal) {
    const apiKey = settings.apiKey?.trim();
    if (!apiKey) {
      emit({
        type: "error",
        message:
          "No Anthropic API key. Add ANTHROPIC_API_KEY to .env, paste a key in Settings, or switch to the local Claude Code provider.",
      });
      return;
    }
    const model = settings.model?.trim() || DEFAULT_API_MODEL;
    const client = new Anthropic({ apiKey });

    const userContent: Anthropic.ContentBlockParam[] = [];
    if (input.imageDataUrl) {
      const { mediaType, base64 } = parseDataUrl(input.imageDataUrl);
      userContent.push({ type: "image", source: { type: "base64", media_type: mediaType, data: base64 } });
    }
    userContent.push({ type: "text", text: buildUserText(input) });

    const messages: Anthropic.MessageParam[] = [{ role: "user", content: userContent }];

    // Haiku 4.5 does not accept adaptive thinking or output_config.effort.
    const supportsAdaptive = !/haiku/i.test(model);

    emit({ type: "status", message: `Sending the sketch to ${model}` });

    const stream = client.messages.stream(
      {
        model,
        max_tokens: 64000,
        system: [{ type: "text", text: buildSystemPrompt(shapeOf(input)), cache_control: { type: "ephemeral" } }],
        ...(supportsAdaptive ? { thinking: { type: "adaptive" }, output_config: { effort: "high" } } : {}),
        messages,
      },
      { signal },
    );

    let announced = false;
    stream.on("text", (delta) => {
      if (!announced) {
        announced = true;
        emit({ type: "status", message: "Writing the prototype" });
      }
      emit({ type: "delta", text: delta });
    });

    try {
      const final = await stream.finalMessage();
      if (final.stop_reason === "refusal") {
        emit({
          type: "error",
          message: `The model declined this request${
            final.stop_details?.explanation ? `: ${final.stop_details.explanation}` : "."
          }`,
        });
        return;
      }
      const text = final.content
        .filter((b): b is Anthropic.TextBlock => b.type === "text")
        .map((b) => b.text)
        .join("");
      if (final.stop_reason === "max_tokens") {
        emit({ type: "status", message: "Output hit the length limit; the document may be cut short." });
      }
      emit({ type: "done", text, usage: final.usage as unknown as Record<string, unknown>, model: final.model });
    } catch (err) {
      if (signal.aborted) return;
      if (err instanceof Anthropic.AuthenticationError) {
        emit({ type: "error", message: "The API key was rejected. Check it in Settings or .env." });
      } else if (err instanceof Anthropic.RateLimitError) {
        emit({ type: "error", message: "Rate limited by the API. Wait a moment and try again." });
      } else if (err instanceof Anthropic.BadRequestError) {
        emit({ type: "error", message: `The API rejected the request: ${err.message}` });
      } else if (err instanceof Anthropic.APIError) {
        emit({ type: "error", message: `API error ${err.status ?? ""}: ${err.message}` });
      } else {
        emit({ type: "error", message: err instanceof Error ? err.message : String(err) });
      }
    }
  },
};
