# Identifying animation instructions
A sketch can ask for motion without saying "animate". Look for these marks, then confirm against the brief.

## Marks that mean motion
- Motion lines: short parallel strokes trailing a shape, or a shape with a dashed ghost copy beside it. The ghost is the start state; the solid shape is the end state.
- A swooping or curved arrow into a position means the element enters from that direction (slide in). A straight arrow with a word on it ("fade", "slide", "pop", "grow", "spin") names the effect.
- Numbered frames or a small filmstrip of the same element are a sequence; play them in order.
- Sparkles, small radiating lines, or a pulse ring mean a subtle attention effect, used once.
- A pointer or hand icon with an arrow means a hover or tap state. "hover → lift", "press", "tap" name the trigger.
- A scroll glyph (vertical arrow, mouse wheel, "scroll ↓", "on scroll", "reveal") means the effect starts when the element scrolls into view.
- "loop", "forever", a circular arrow, or "∞" means ambient looping motion.
- "sticky", "fixed", "pinned" are scroll behaviour, not animation. "parallax" is scroll-linked movement.
- Timing hints: "fast", "slow", "0.3s", "300ms", "after the headline".

## Classify every motion by trigger
load (entrance, once) · scroll (into view, once) · hover/focus · click/tap state · loop (ambient). If the trigger is unclear, choose a user-triggered one (hover, click, scroll) over an ambient loop, and say so under "unclear".

## Implement it
- CSS transitions for state changes (150–300ms), keyframes for entrances (400–700ms, ease-out), a small IntersectionObserver for scroll reveals. No animation libraries.
- The page must read correctly without JavaScript and before any animation runs: never leave content at opacity 0 waiting for a script; add the "ready" class from the script and style the hidden state only under that class.
- Wrap all non-essential motion in `@media (prefers-reduced-motion: no-preference)` or disable it under `prefers-reduced-motion: reduce`.
- One orchestrated entrance beats motion on every element. Do not add motion the sketch and brief did not ask for.
- Report each motion in the analysis under "motion" with the element, trigger, effect, and duration, so the reader can check it was understood.
