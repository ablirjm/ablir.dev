# Reading a rough sketch
Most sketches are messy: photographed on a desk, drawn fast, corrected in place. Read intent, not geometry.

- Near-rectangles count as rectangles: open corners, overshooting lines, wobble, and a missing fourth side are all the same box. Align boxes to a grid; boxes of roughly equal size (within about a fifth) are equal columns.
- Count what is drawn, not what is neat. Three uneven cards are three cards. "x3", "×4", "..." or "etc" next to an element means repeat it that many times, or a sensible number if none is given.
- A shape scribbled over, or text struck through with a zigzag or a single line, is deleted. Omit it. (An X that fills a box is still an image placeholder; a scribble that obscures a shape is a deletion.)
- Overlapping shapes: the one with a label wins. A shape drawn on top of another suggests layering, such as a dialog or card over an image.
- Faint, partial, or repeated strokes: use the darkest, most complete version and ignore the rest.
- Photo artifacts are not content: shadows, creases, stains, ruled lines, paper edges, binder holes, fingers, the table. Ballpoint blue, pencil grey, and black are all ink.
- Illegible words: infer from position and context (a word in a top bar is a nav label; a word in a small rounded box is a button). If you cannot, choose the most likely reading and report it under "unclear" with your alternative. Never render the illegible scribble itself as text.
- A "?" beside a mark means the decision is yours; make it and report it under "unclear".
- Arrows that leave the page or point at nothing are emphasis, not navigation.
- When the whole sketch is too rough to be sure of a region, prefer the simplest layout that fits the marks and say so in "assumptions".
